function More() {
    return <h2>More page</h2>;
}

export default More;
