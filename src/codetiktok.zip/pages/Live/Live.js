function Live() {
    return <h1>Live Page</h1>;
}

export default Live;
