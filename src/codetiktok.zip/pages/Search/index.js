function Search() {
    return <h2>Search page</h2>;
}

export default Search;
